package com.example.pharmacy.service;

public class ejemplo {
    
}
